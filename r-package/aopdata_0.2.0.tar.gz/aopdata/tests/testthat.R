library(testthat)
library(aopdata)

test_check("aopdata")
