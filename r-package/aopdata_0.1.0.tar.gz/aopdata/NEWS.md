# log history of aopdata package development

-------------------------------------------------------

# aopdata v0.1.0 (dev)


**Major changes**
* New parameter `peak` added to `read_access()` function. Closes #17.

**Minor changes**
* Downloads two or more cities at the same time. Closes #3.



-------------------------------------------------------

# aopdata v0.0.1

* Submitted to CRAN
